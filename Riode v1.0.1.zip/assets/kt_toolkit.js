if (!theme.csrfToken) {
  $.ajax({
    type: "GET",
    url: "/admin/themes/"+Shopify.theme.id,
    success: function (data){
      theme.csrfToken = data.split('name="csrf-token"')[1].split(" />")[0].split('"')[1];
    }
  });
}
// $.ajax({
//   url:  $('.selector-it').attr('data-include'),
//   type: 'GET',
//   dataType: 'html',
// })
// .done(function(data) {
//   $('.selector-it').append(data)
// });
// KT.loadScript('isotope', function(e,l) {});
// $(document).on('shown.bs.modal', '#importSectionModal', function (event) {
//   $('.selector-it').isotope({
//     // options
//     itemSelector: '.section-it',
//     layoutMode: 'packery',
//     packery: {
//       horizontalOrder: true,
//       percentPosition: true
//     },
//     transitionDuration: '.4s',
//     filter: '.demo-homep'
//   });  
// });
$(document).on('click', '.t4-import-dm-i .t4-import-btn', function (event) {
  event.preventDefault();
  var $this = $(this);
  $('.t4-import-btn').addClass('loading');
  $.ajax({
    url:  '/admin/api/2021-10/themes/'+Shopify.theme.id+'/assets.json',
    headers: {
      "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
      "x-csrf-token": theme.csrfToken
    },
    type: 'PUT',
    data: {asset:  { 'key': 'templates/index.json', 'src': $this.attr('data-js')}},
  })
  .done(function() {    
    $.ajax({
      url:  '/admin/api/2021-10/themes/'+Shopify.theme.id+'/assets.json',
      headers: {
        "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        "x-csrf-token": theme.csrfToken
      },
      type: 'PUT',
      data: {asset:  { 'key': 'config/settings_data.json', 'src': $this.attr('data-js').replace('index', 'settings')}},
    })
    .done(function() {
      $('.t4-import-btn').removeClass('loading');
      window.top.location.reload();
    });
  });
});
// var fv_tpl = sessionStorage.getItem('fv_tpl');
// $(document).on('click', '.t4-favourites', function (event) {
//   event.preventDefault();
//   var $this = $(this);
//   $(this).toggleClass('added');
  
// });