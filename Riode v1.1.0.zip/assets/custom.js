(function($) { 
  "use strict";
  /* ---------------------------------------------
  SEARCH
   --------------------------------------------- */
  KT.ajaxSearch = function(){
    if(theme.function.searchAjax === false){return false};
    var $current_search;
    function init(element){
      clearTimeout($current_search);
      var $val = element.val();
      var $this = element.parents('form.box-search');
      var $typeSearch = theme.function.searchAjaxTypes;
      var $url = '';
      if (theme.function.searchTypesDrop) {
        var $thisSelected = $this.find(".searchTypes");
        if($thisSelected.val() !== '' && $thisSelected.val() !== undefined){
          $val = 'product_type:'+ $thisSelected.val();
          if ($this.find("input.search").val() !== '' && $this.find("input.search").val()  !== undefined) {
            $val = $val + ' AND ' + $this.find("input.search").val();
          }
        }
      }
      if($val.trim() == '') {
        $this.removeClass('loading loaded');
        $this.find('.button-search').removeClass('loading loaded');
        $this.find(".li--s").html('');
        return false;
      }else{
        $this.find(".li--s").html('<li class="col-12"><div class="col-12 py-1 lz-place pin-search-place"></div></li>');
        $this.addClass('loading');
        $this.find('.button-search').addClass('loading');
        $current_search = setTimeout(function(){
          $.ajax({
            url: Shopify.root_url+"/search/suggest",
            type: 'GET',
            dataType: 'html',
            data: {
              "q": $val,
              "resources": {
                "type": $typeSearch,
                "options": {
                  "unavailable_products": "last",
                  "fields": "author,body,product_type,tag,title,variants.barcode,variants.sku,variants.title,vendor"
                }
              },
              "section_id": "kt_canvas_search"
            }
          })
          .done(function(data) {
            // console.log("success");
            var htmlResult = data.split('<!--lz_sc-->')[1];
            $this.find(".li--s").html(htmlResult);
            $this.removeClass('loading').addClass('loaded');
            $this.find('.button-search').removeClass('loading loaded');
          })
          .fail(function() {
            // console.log("error");
          });
          // (Shopify.root_url+"/search/suggest", {
          //   "q": $val,
          //   "resources": {
          //     "type": $typeSearch,
          //     "options": {
          //       "unavailable_products": "last",
          //       "fields": "author,body,product_type,tag,title,variants.barcode,variants.sku,variants.title,vendor"
          //     }
          //   },
          //   "section_id": "kt_canvas_search"
          // }).done(function(response) {
            // var articles = response.resources.results.articles;
            // var pages = response.resources.results.pages;
            // var products = response.resources.results.products;
            // var htmlResult = response;
            // if (products.length > 0) {
            //   $.each(products, function(index, prd) {
            //     htmlResult += productLayout(prd);
            //   });
            // }
            // if (pages !== undefined && pages.length > 0) {
            //   htmlResult += '<li class="item-search pages_obj">';
            //     htmlResult += '<div class="name_type">'+theme.strings.search_dropdown_pages+'</div>';
            //     htmlResult += '<ul class="list-unstyled">';
            //     $.each(pages, function(index, page) {
            //       htmlResult += pageLayout(page);
            //     });
            //     htmlResult += '</ul> ';
            //   htmlResult += '</li> ';
            // }
            // if (articles !== undefined && articles.length > 0) {
            //   htmlResult += '<li class="item-search pages_obj">';
            //     htmlResult += '<div class="name_type">'+theme.strings.search_dropdown_articles+'</div>';
            //     htmlResult += '<ul class="list-unstyled">';
            //     $.each(articles, function(index, article) {
            //       htmlResult += articleLayout(article);
            //     });
            //     htmlResult += '</ul>';
            //   htmlResult += '</li>';
            // }
            // if (htmlResult === ''){
            //   htmlResult += '<li class="col-12"><h4 class="mb-0 py-1">'+theme.strings.search_dropdown_no_results+'</h4></li>';
            // }
            // $this.find(".li--s").html(htmlResult);
            // $this.removeClass('loading').addClass('loaded');
            // $this.find('.button-search').removeClass('loading loaded');
            // if ($(".li--s .shopify-product-reviews-badge").length > 0 && typeof window.SPR == 'function') {
            //   return window.SPR.registerCallbacks(), window.SPR.initRatingHandler(), window.SPR.initDomEls(), window.SPR.loadProducts(), window.SPR.loadBadges();
            // }
          // })
        }, 400);
      }
    }
    // function productLayout(product) {
    //   var html = ''
    //   html += '<li class="item-search">';
    //     html += '<a href="'+product.url+'">';
    //       html += '<div class="thumb is-contain">';
    //       if(product.image){
    //         html += '<div class="aspectRatio"><img src="'+theme.Images.getSizedImageUrl(product.image, '240x')+'" alt="'+product.title+'"></div>';
    //       }
    //       html += '</div>';
    //       html += '<div class="product-info">';
    //         html += '<h4 class="product-name">'+product.title+'</h4>';
    //         html += '<div class="product-description">';
    //         html += '</div>';
    //         html += '<div class="rating">';
    //           html += '<span class="shopify-product-reviews-badge" data-id="'+product.id+'"></span>';
    //         html += '</div>';
    //         html += '<span class="price">';
    //           html += '<ins>'+formatMoney_(product.price)+'</ins>';
    //           if(product.compare_at_price > product.price){
    //           html += '<del>'+formatMoney_(product.compare_at_price)+' </del>';
    //           }
    //         html += '</span>';
    //       html += '</div>';
    //     html += '</a>';
    //   html += '</li> ';
    //   return html;
    // }
    // function pageLayout(page) {
    //   var html = ''
    //   html += '<li>';
    //     html += '<a href="'+page.url+'">';
    //     html += page.title;
    //     html += '</a>';
    //   html += '</li> ';
    //   return html;
    // }
    // function articleLayout(article) {
    //   var html = ''
    //   html += '<li>';
    //     html += '<a href="'+article.url+'">';
    //     html += article.title;
    //     html += '</a>';
    //   html += '</li> ';
    //   return html;
    // }
    $(document)
    .on('keyup','.box-search input.search', function(event) {
      event.preventDefault();
      var $this = $(this);
      $("input.search").not($this).val($this.val());
      init($this)
    })
    .on('click','.box-search.show input.search', function(event) {
      event.preventDefault();
      var $this = $(this);
      var $val_input = $(this).val();
      if ($val_input === '' || $this.parents('.box-search.show').find('.li--s li').length > 0) {return false}
      init($this)
    })
    .on('change','.box-search .searchTypes', function(event) {
      event.preventDefault();
      var $this = $(this);
      var $val_input = $(this).val();
      if ($val_input === '' || $this.parents('.box-search.show').find('.li--s li').length > 0) {return false};
      $('.searchTypes').val($val_input);
      init($this)
    })
    .on('click', function(e){
      if ($(e.target).is('.box-search') === false && $(e.target).is('.box-search *') === false) {
        $('.box-search').removeClass('loaded');        
        $('.li--s').empty();
      }
      if ($(e.target).is('.box-search input') === false) {
        $('.box-search').removeClass('focus');
      }
    })
    .on("focus",".box-search input.search", function(evt) {
      if ($(this).parents('.box-search').hasClass('focus') === false) {
        $(this).parents('.box-search').addClass('focus');
      }
    });
  }
    
  /* ---------------------------------------------
   QUICKVIEW
   --------------------------------------------- */
  function kt_quickView(){
    let $modal = $('#rd_qvModal');
    $(document).on('click', '.quick-view', function(event) {
      event.preventDefault();
      var $this = $(this);
      var url = $this.attr('data-view').split('?')[0];
      var vr_id = $(this).parents('.product-inner').find('input[name="id"]').val();
      $this.addClass('loading');
      if ($modal.attr('data-view') == url) {
        $this.removeClass('loading');
        $modal.modal('show');
        return false;
      }
      $('#ProductSection-quickview-template').off();
      $('#ProductSection-quickview-template').find('.kt_countdown').off();
      $('.kt_630-quickview-template').remove();
      $('#sizeGuide_and_shipping').remove();
      $.ajax({
        url: url+'?variant='+vr_id+'&view=quick-view',
        type: 'GET',
        success: function(data){
          var content = data.split('<!-- sizeGuide_and_shipping -->');
          var script = content[2].split('<!-- noscript -->')[1].replace(/(noscript)/gm, 'script');
          $('.product-quickview-content').html(content[2].split('<!-- noscript -->')[0]);
          $('.product-quickview-content').append(script);
          $('body').append('<div id="sizeGuide_and_shipping">'+content[1]+'</div>');
          $this.removeClass('loading');
          var sections = new theme.Sections();
          sections.register('product', theme.Product);
          $modal.attr('data-view',url).modal('show');
          var prefetch = document.createElement('link');
          prefetch.rel = "prefetch";
          prefetch.href = url;
          prefetch.onload = function() {
            $(this).remove();
          };
          headDocument.insertBefore(prefetch, firstLink);
        }
      });
    });
  }

  /* ---------------------------------------------
   QUICKSHOP
   --------------------------------------------- */
  function kt_quickShop(){
    let $modal = $('#quickShop-modal');
    $(document).on('click', '.kt__quick-shop', function(event) {
      event.preventDefault();
      var $this = $(this);
      var $data = $this.data();
      if ($('#qs-'+$data.pid).length > 0){
        $('.modalQuickShop .modal-content').attr('data-pid', $data.pid).html($('#qs-'+$data.pid)[0].innerText);
        $modal.modal('show');
        return false;
      } else {
        var url = $data.view.split('?')[0]+'?view=qshop';
        if ($data.vrid !== undefined) {
          url = $data.view.split('?')[0]+'?variant='+$data.vrid+'&view=qshop';
        }
        KT.loadScript('qs-css', function(e,l) {});
        $.ajax({
          url: url,
          type: 'GET',
          success: function(data) {
            $('.modalQuickShop .modal-content').attr('data-pid', $data.pid).html(data);
            $modal.modal('show');
            theme.wokerktlz.load();
          }
        });
      }
    });
    $(document).on('variantsLoaded', '.modalQuickShop form', function (event){
      var variant = event.variant;
      $('.modalQuickShop').find('ul._small').removeClass('_small');
    });
    $(document).on('shown.bs.modal', '#quickShop-modal', function (event) {
      $('head link').first().after('<link class="prefetch-product" rel="prefetch" href="'+$('.kt__quick-shop.loading').attr('data-view')+'">');
      $('.kt__quick-shop.loading').removeClass('loading');
    })
    $(document).on('hidden.bs.modal', '#quickShop-modal', function (event) {
      if ($('#qs-'+$('.modalQuickShop .modal-content').attr('data-pid')).length <= 0){
        $('body').append('<noscript id="qs-'+$('.modalQuickShop .modal-content').attr('data-pid')+'">'+$('.modalQuickShop .modal-content').html()+'</noscript>');
      }
      $('.modalQuickShop .modal-content').html('');
    })
  }

  /* ---------------------------------------------
   EDIT OPTIONS
   --------------------------------------------- */
  function kt_editOpts(){
    var $offcanvas = $('#editOptsOffcanvas');
    $(document).on('click', '.kt__edit-opts', function(event) {
      event.preventDefault();
      var $this = $(this);
      var $data = $this.data();
      if ($('#eo-'+$data.pid).length > 0){
        $('#editOptsOffcanvas .offcanvas-body').attr('data-pid', $data.pid).html($('#eo-'+$data.pid)[0].innerText);
        return false;
      } else {
        var url = $data.view.split('?')[0]+'?view=edit-opts';
        if ($data.vrid !== undefined) {
          url = $data.view.split('?')[0]+'?variant='+$data.vrid+'&view=edit-opts';
        }
        $.ajax({
          url: url,
          type: 'GET',
          success: function(data) {
            $('#editOptsOffcanvas .offcanvas-body').attr('data-pid', $data.pid).html(data);
            if($data.qty !== undefined) {
              $('#editOptsOffcanvas').find('#qty-eo').val($data.qty);
              $('#editOptsOffcanvas').find('[name="updates['+$data.vrid+']"]').val($data.qty);
              $('#editOptsOffcanvas').find('.it-qty').html($data.qty);
            }
            setTimeout(function(){
              $('#editOptsOffcanvas').find('[name="id"]').remove();
            }, 300)
          }
        });
      }
    });
    $(document).on('variantChange', '#editOptsOffcanvas form', function (event){
      var variant = event.variant;
      $('#qty-eo').attr('data-id', variant.id);
      $('.it-ip-editing').val(0);
      if ($('.it-ip-edited').length <= 0) {
        $('.it-ip-editing').removeClass('it-ip-editing').addClass('it-ip-edited');
        $('#editOptsOffcanvas form').append('<input class="it-ip-editing" type="hidden" name="updates['+$('#qty-eo').attr('data-id')+']" value="'+$('#qty-eo').val()+'">');
      } else {
        $('.it-ip-editing').attr({'name': 'updates['+$('#qty-eo').attr('data-id')+']', 'value': $('#qty-eo').val()});
      }
    });
    $(document).on('change', '#qty-eo', function () {
      $('#editOptsOffcanvas [name="updates['+$(this).attr('data-id')+']"]').val($(this).val());
    })
    $(document).on('hidden.bs.offcanvas', '#editOptsOffcanvas', function () {
      if ($('#eo-'+$('#editOptsOffcanvas .offcanvas-body').attr('data-pid')).length <= 0){
        $('body').append('<noscript id="eo-'+$('#editOptsOffcanvas .offcanvas-body').attr('data-pid')+'">'+$('#editOptsOffcanvas .offcanvas-body').html()+'</noscript>');
      }
      $('#editOptsOffcanvas .offcanvas-body').html('');
    });
    $(document).on('variantsLoaded', '#editOptsOffcanvas form', function (event){
      var variant = event.variant;
      $('#editOptsOffcanvas').find(' ul._small').removeClass('_small').addClass('_huge');
    });
  }
    
  /* ---------------------------------------------
   WISHLIST LOCAL
   --------------------------------------------- */
  function AutoloadWishlist(){
    var stringProduct = localStorage.getItem("kt-wishlist");
    var wishlist_page = $('.wishlist-page-items');
    if(stringProduct == null){$('.table-wishlist').hide();$('.wishlist-empty').show();return false};
    if(stringProduct.length !== 0){ 
      var arrayProduct = stringProduct.split(',');
      theme.wishlist.list = arrayProduct;
      $('.wishlist-count').text(arrayProduct.length);
      $.each(arrayProduct, function(idx, handle) {
        if (handle !== '' && handle !== null) {
          var $btn = $('.kt-wishlist[data-handle="'+handle+'"]');
          $btn.addClass('added').attr({'data-action': 'view', 'data-href': theme.wishlist.page_local});
          $btn.find('.btn-name').html(theme.wishlist.view);
        }
      });
      if (wishlist_page) {
        var buildItemsInPage = arrayProduct.map(itemsInPage, stringProduct);
        wishlist_page.html(buildItemsInPage.join());
      }
    } else if(wishlist_page) {
      $('.table-wishlist').hide();
      $('.wishlist-empty').show();
    }
    function itemsInPage(itemHandle) {
      return `<tr class="wishlist-page-item lazyload" id="WishItem-${itemHandle}" data-include="${Shopify.root_url}/products/${itemHandle}?view=wishlist">`
        +`<td class="product-col">`
          +`<div class="product d-flex align-content-stretch">`
            +`<figure class="product-media"><div class="lz-place"></div></figure>`
            +`<div class="w-100"><div class="lz-place"></div></div>`
          +`</div>`
        +`</td>`
        +`<td class="price-col"><div class="lz-place"></div></td>`
        +`<td class="stock-col"><div class="lz-place"></div></td>`
        +`<td class="action-col"><div class="lz-place"></div></td>`
        +`<td class="remove-col"><div class="lz-place"></div></td>`
      +`</tr>`;
    }
    function check(mutationsList, observer) {
      for (i = 0; i < mutationsList.length; i++) {
        var mutation = mutationsList[i];
        if (mutation.target.outerHTML.includes('kt-wishlist')) {
          var wishlist_btns = mutation.target.querySelectorAll('.kt-wishlist');
          for (i = 0; i < wishlist_btns.length; i++) {
            var handle = wishlist_btns[i].getAttribute("data-handle");
            if (theme.wishlist.list.includes(handle)) {
              var $btn = $('.kt-wishlist[data-handle="'+handle+'"]');
              $btn.addClass('added').attr({'data-action': 'view', 'data-href': theme.wishlist.page_local});
              $btn.find('.btn-name').html(theme.wishlist.view);
            }
          }
          return false;
        }
      }
    }
    var observer_wishlist = new MutationObserver($.throttle( 200, check));
    observer_wishlist.observe(document.querySelector('body'), { attributes: true, childList: true, subtree: true })
  }
  function AddWishlist(){
    $('body').on('click', '.kt-wishlist', function(event) {
      var $this = $(this);
      if ($this.attr('data-action') == "view") {
        window.location.href = $this.attr('data-href');
        return false;
      }
      event.preventDefault();

      /* Act on the event */
      var handle = $this.data('handle'),
          stringProduct = localStorage.getItem("kt-wishlist");
      if(stringProduct !== null && stringProduct.length > 1){ 
        var arrayProduct = stringProduct.split(',');
      }else{
        var arrayProduct = new Array;
      }
      if(arrayProduct.indexOf(handle) < 0){
        arrayProduct.push(handle);
        if (arrayProduct.length > 1) {
          var arrayProduct_ = arrayProduct.join(',');
          if (arrayProduct_.substring(0, 1) == ',') { 
            arrayProduct_ = arrayProduct_.substring(1);
          }
        }else{
          arrayProduct_ = arrayProduct.toString();
        }
        $('.wishlist-count').text(arrayProduct.length);
        localStorage.setItem("kt-wishlist", arrayProduct_);
      }
      $this.addClass('added').attr({'data-action': 'view', 'data-href': theme.wishlist.page_local});
      $this.find('.btn-name').html(theme.wishlist.view);
    });
  }
  function RemoveWishlist(){    
    $(document).on('click', '.wishlist-remove', function(event) {
      event.preventDefault();
      var $this = $(this), handle = $this.attr('data-handle');
      var $btn = $('.kt-wishlist[data-handle="'+handle+'"]');
      $btn.removeClass('added').attr({'data-action': 'add', 'data-href': '#'});
      $btn.find('.btn-name').html(theme.wishlist.add);
      var list_handle = localStorage.getItem("kt-wishlist");      
      if(list_handle !== null){ 
        var arrayProduct = list_handle.split(',');
      }
      arrayProduct = $.grep(arrayProduct, function(value) {
        return value != handle;
      });
      arrayProduct = $.trim(arrayProduct);
      $('.wishlist-count').text(arrayProduct.length);
      localStorage.setItem("kt-wishlist", arrayProduct.toString());      
      $('#WishItem-' + handle).fadeOut(300, function(){
        $(this).remove();
        if(arrayProduct == 0) {
          $('.table-wishlist').hide();
          $('.wishlist-empty').show();
        }
      });
    });
  }
  
  /* ---------------------------------------------
   COMPARE
   --------------------------------------------- */
  function AutoloadCompare(){
    var ids = localStorage.getItem("kt-compare");
    if(ids != null && ids.length > 1){ 
      ids = ids.split(',');
      $('.compareCount').text(ids.length);
      $('.no-compare').hide();
      $.each(ids, function(index, id) {
        $(".compare[data-pid='"+id+"']").addClass('added').find('span').html(theme.compare.view);
      });
      if($('.mini-compare-content').length){
        $(document).on('mouseenter', '.mini-compare .icon-link', function() {
          if ($('.mini-compare').hasClass('load')) {
            $('.mini-compare').removeClass('load');
            $(this).find('.kt-button').addClass('loading');
            KT.loadMiniCompare();
          } else {
            return
          }
        });
      }
    } else {
      $('.no-compare').show();
    }
  }
  function AddCompare(){
    $('body').on('click', '.compare', function(event) {
      event.preventDefault();
      if($(this).hasClass('added')){
        $('#compareOffcanvas').offcanvas('show');
        return false;
      }
      /* Act on the event */
      var $this = $(this),
          id = $this.attr('data-pid'),
          ids = localStorage.getItem("kt-compare");
      $this.addClass('loading');
      if(ids !== null && ids.length > 1){ 
        ids = ids.split(',');
      }else{
        ids = new Array;
      }
      if(ids.indexOf(id) < 0 && $(this).hasClass('added') === false ){
        ids.push(id);
        $('.compareCount').text(ids.length);
        localStorage.setItem("kt-compare", ids.toString());
      }      
      $('.no-compare').hide();
      AutoloadCompare();
      $this.removeClass('loading').addClass('added').find('span').html(theme.compare.view);
    });
  }
  function RemoveCompare(){
    $(document).on('click', '.compare-remove', function(event) {
      event.preventDefault();
      var $this = $(this), id = $this.attr('data-pid');
      $('.compare[data-pid="'+id+'"]' ).removeClass('added').find('span').html(theme.compare.add);;
      var ids = localStorage.getItem("kt-compare");
      if(ids !== null && ids.length > 1){ 
        ids = ids.split(',');
      }
      ids = $.grep(ids, function(value) {
        return value != id;
      });
      ids = $.trim(ids);        
      $('.compareCount').text(ids.split(',').length);
      localStorage.setItem("kt-compare", ids.toString());
      $('.cp-'+id).animate({
        opacity: 0
      }, 300, function() {
        $('.cp-'+id).remove()
      });
      if(ids.length === 0){
        $('.no-compare').show();
        $(".mini-compare-content .mini-compare-body").hide(0);
      }
    });
    $(document).on('click', '.compare-remove-all', function(event) {
      event.preventDefault();
      var ids = localStorage.getItem("kt-compare").split(',');
      ids.map(function(id, idx) {
        $('.cp-'+id).remove();
      })
      localStorage.removeItem("kt-compare");
      $('.no-compare').show();
      $(".mini-compare-content .mini-compare-body").hide(0);
    });
  }
  KT.loadMiniCompare = function(){
    var ids = localStorage.getItem("kt-compare");
    if(ids != null && ids.length > 1){      
      ids = ids.split(',');
      $(".mini-compare-content .mini-compare-body").show(0);
      var html = `<ul class="compare-products list-unstyled"></ul>`
              +`<div class="compare-actions">`
              +`<button class="btn btn-primary btn-block btn-rounded" data-bs-toggle="offcanvas" data-bs-target="#compareOffcanvas" aria-controls="compareOffcanvas">${theme.compare.mini_title}</button>`
              +`<button class="compare-remove-all btn btn-link btn-underline sm ms-4">${theme.compare.clear_all}</button>`
              +`</div>`;
      $(".mini-compare-content .mini-compare-body").html(html);
      $.getJSON(Shopify.root_url+"/search/suggest.json", {
        "q": 'id:'+ids.join(" OR id:"),
        "resources": {
          "type": "product"
        }
      }).done(function(response) {
        var products = response.resources.results.products;
        var html_item = "";
        $.each(products, function(idx, product) {
          html_item += `<li class="compare-product cp-${product.id}">`
            +`<button class="compare-remove btn-remove btn-close _p-0" data-pid="${product.id}" title="${theme.strings.remove}"></button>`
            +`<h4 class="compare-product-title"><a href="${product.url}">${product.title}</a></h4>`
            +`</li>`;
        })
        $(".mini-compare-content .compare-products").html(html_item);
        $('.mini-compare .kt-button').removeClass('loading');
      })
    }else{
      $(".mini-compare-content .mini-compare-body").hide(0);
      $('.mini-compare .kt-button').removeClass('loading');
    }
  }
  $(document).on('show.bs.offcanvas', '#compareOffcanvas', function () {
    var ids = localStorage.getItem("kt-compare"); 
    if(ids !== null && ids.length > 1){ 
      ids = ids.split(',');
      var url = Shopify.root_url+'/search?q=id:'+ids.join("%20OR%20id:")+'&view=compare';
      $.ajax({
        url: url,
        type: "GET",
        success: function (data) {
          $('#compare-content').html(data);
          $('#compareOffcanvas').offcanvas('show');
          AutoloadCompare();
        }
      })
    }
  });

  /* ---------------------------------------------
   CSS BANNER WAIT
   --------------------------------------------- */  
  function css_banner_builded(){
    if ($('.banner-css').length <= 0) {return;}
    var css_banner = '';
    var array_banner = new Array;
    $('.banner-css').each(function(){
      var sectionType = $(this).data().sectionType;
      if (array_banner.indexOf(sectionType) >= 0) {return}else{array_banner.push(sectionType)}
      css_banner += $(this)[0].innerText;
    });
    css_banner = css_banner.replace(/<.*?>/gm,'').replace(/(\r\n|\n|\r|\s\s)/gm, "");
    if ($('.css_banner_builded').length == 0) {
      $('script').first().before('<style class="css_banner_builded">'+css_banner+'</style>');
    }else{
      $('.css_banner_builded').html(css_banner)
    }
    $('.wait-for-css').removeClass('wait-for-css');
  }

  /* ---------------------------------------------
   RESPONSIVE IFRAME
   --------------------------------------------- */
  function embedRespon(){
    var players = theme.embedResponPlayer;
    var fitVids = $(players.join(","));
    if (fitVids.length) {
      for (var i = 0; i < fitVids.length; i++) {
        var fitVid = $(fitVids[i]);
        if (fitVid.hasClass('embed-responsive-item')) {return true}
        var width = fitVid.attr("width") || 560;
        var height = fitVid.attr("height") || 315;
        var aspectRatio = height / width;
        fitVid.addClass('embed-responsive-item');
        if (fitVid.hasClass('fullw')) {
        var div = '<div style="width:100%;"><div class="embed-responsive" style="padding-bottom: '+aspectRatio * 100+'%">'+fitVid[0].outerHTML+'</div>';
        } else {
        var div = '<div style="width:100%;max-width:'+width+'"><div class="embed-responsive" style="padding-bottom: '+aspectRatio * 100+'%">'+fitVid[0].outerHTML+'</div>';
        }
        fitVid.after(div).remove();
      }
    }
  }

  /* ---------------------------------------------
   SUGGEST PRODUCTS
   --------------------------------------------- */
  function suggestProducts() {
    var sggPrds = sessionStorage.getItem('sggPrds');
    var curNewsIndex = 0;
    var delay_time = theme.suggest.delay_time;
    var show_time = theme.suggest.show_time;
    var all_time = 5000;
    var $thisSuggest = $('.kt-products-suggest');
    var intervalID;
    var intervalShow;
    var intervalShowTime;
    if ($thisSuggest.length <= 0) {return false}
    
    function advanceNewsItem() {
      if(sggPrds.length == 0){return;}
      curNewsIndex = Math.floor(Math.random() * sggPrds.length);
      var spaceBottom = 15;
      if($('.kt-stickyAddCart.fixed').length > 1){
        spaceBottom = $('.kt-stickyAddCart.fixed').outerHeight() + 15;
      }
      if($('.kt-cookies-popup').length > 1){
        spaceBottom = $('.kt-cookies-popup').outerHeight() + 15;
      }
      $thisSuggest.animate({bottom: ($thisSuggest.width()+spaceBottom)*-1+'px',opacity: 0},600);
      function funShow(){
        $thisSuggest.show();
        var sggPrd = sggPrds[curNewsIndex];
        if (theme.suggest.use_fake_location && theme.suggest.arr_fake_location.length > 0) {
          var myArray = theme.suggest.arr_fake_location, rand = Math.floor(Math.random() * theme.suggest.arr_fake_location.length);
        }
        var fakeTimeOrder = Math.floor((Math.random() * 60) + 1);
        $thisSuggest.find('.product-title').html(sggPrd.title).attr('href',theme.suggest.collection_opj+sggPrd.url);
        $thisSuggest.find('.table-cell-top.img a').attr('href',theme.suggest.collection_opj+sggPrd.url);
        $thisSuggest.find('.table-cell-top.img img').attr( { src:sggPrd.image, alt:sggPrd.title } );
        $thisSuggest.find('.minute-number').html(fakeTimeOrder);
        if (theme.suggest.use_fake_location && theme.suggest.arr_fake_location.length > 0) {
          $thisSuggest.find('.from').html(myArray[rand]);
        }
        $thisSuggest.animate({bottom: spaceBottom+'px',opacity: 1},600);
        clearInterval(intervalShow);
      }
      function funShowTime(){
        $thisSuggest.animate({bottom: ($thisSuggest.width()+spaceBottom)*-1+'px',opacity: 0},600);
        clearInterval(intervalShowTime);
      }
      intervalShow = setInterval(funShow, 600);
      intervalShowTime = setInterval(funShowTime, show_time);
    }
    if (sggPrds !== null) {
      sggPrds = jQuery.parseJSON(sggPrds);
      if(sggPrds.length == 0){return;}
      setTimeout(function() {
        advanceNewsItem();
      }, 1000);
      var intervalID = setInterval(advanceNewsItem, delay_time + show_time);
    } else {
      $.ajax({
        url: (theme.suggest.collection_opj || allPrdUrl) + '?view=suggest',
        type: 'GET',
        dataType: 'html'
      })
      .done(function(data) {
        // console.log("success");
        sggPrds = jQuery.parseJSON(data.replace(/<!--.*?-->/g, ""));
        sessionStorage.setItem('sggPrds', JSON.stringify(sggPrds));
        setTimeout(function() {
          advanceNewsItem();
        }, 1000);
        var intervalID = setInterval(advanceNewsItem, delay_time + show_time);
      })
      .fail(function() {
        // console.log("error");
      });
    }
    var check_mouse = true;
    $thisSuggest.on({
      mouseenter: function () {
        if (check_mouse) {
          clearInterval(intervalShow);
          clearInterval(intervalShowTime);
          check_mouse = false;
       }
      },
      mouseleave: function () {
        intervalID = setInterval(advanceNewsItem, delay_time + show_time);
        check_mouse = true;
      }
    });
    $('.suggest-close').on('click', function(event) {
      event.preventDefault();
      $(this).parent().parent().remove()
    });
  }

  /* ---------------------------------------------
   CART DRAWER
  --------------------------------------------- */
  $(document).on('show.bs.offcanvas', '#cartOffcanvas', function () {
    if ($('.mini-cart').hasClass('load')) {
      $('.mini-cart').removeClass('load');
      if(theme.function.ajax_cart){
        $('.content__cart-offcanvas').addClass('loading');
        Shopify.KT_getCart();
      }
    }
    KT.drawResize();
  })
  KT.drawResize = function(){
    var headHeight = $('.cart-offcanvas .offcanvas-header').outerHeight();
    var footHeight = $('.footer__cart-offcanvas').outerHeight();
    $('.content__cart-offcanvas').css('min-height', theme.window_H - footHeight - headHeight+'px')
  }

  /* ---------------------------------------------
   COUNTDOWN WITHOUT SECTION
  --------------------------------------------- */
  KT.countdown = function(){
    $('.kt_countdown').each(function(){
      if ($(this).parents('[data-section-type="countdown-section"]').length <= 0) {
        var el = $(this).parents('[data-section-type]');
        if (el.length > 0){
          if(el.hasClass('product-page')) {
            return true
          }
          theme.ktCountdown(el);
        } else {
          theme.ktCountdown($(this));
        }
      }
    });
  }

  /* ---------------------------------------------
   RESPONSIVE SPACE SECTION
   --------------------------------------------- */
  KT.respSpaceSc = function(el){
    var resp_0 = '',resp_1 = '',resp_2 = '',resp_3 = '',resp_4 = '',resp_5 = '';
    // 0, 576px, 768px, 992px, 1200px, 1230px
    var query0 = "screen and (min-width: 0px)",
        query1 = "screen and (min-width: 576px)",
        query2 = "screen and (min-width: 768px)",
        query3 = "screen and (min-width: 992px)",
        query4 = "screen and (min-width: 1200px)",
        query5 = "screen and (min-width: 1400px)",
    respSpace = function(el,count){
      var respon = el.attr('data-respon');
      // if (respon.indexOf('|') < 0) {return ''}
      var elData = JSON.parse(respon.replace(/'/g,'"'));
      var resp_ = elData.el + '{';
      if (elData.mt !== '') {
        var mt = elData.mt.toString().split('|');
        resp_ += mt[count] !== undefined ? 'margin-top:' + mt[count] + ';' : '';
      }
      if (elData.mb !== '') {
        var mb = elData.mb.toString().split('|');
        resp_ += mb[count] !== undefined ? 'margin-bottom:' + mb[count] + ';' : '';
      }
      if (elData.p !== '') {
        var p = elData.p.toString().split('|');
        if (elData.elp == undefined) {
          resp_ += p[count] !== undefined ? 'padding:' + p[count] + ';' : '';
          resp_ === elData.el + '{' ? resp_ = '' : resp_ += '}';
        } else if(p[count] !== undefined) {
          resp_ === elData.el + '{' ? resp_ = '' : resp_ += '}';
          resp_ += elData.elp + '{';
          resp_ += p[count] !== undefined ? 'padding:' + p[count] + ';' : '';
          resp_ += '}';
        } else {
          resp_ === elData.el + '{' ? resp_ = '' : resp_ += '}';
        }
      } else {
       resp_ === elData.el + '{' ? resp_ = '' : resp_ += '}';
      }
      return resp_;
    },
    el_respon = $('[data-respon]'),
    handler0 = {
        match : function() {
          if (el !== undefined) {
            resp_0 += respSpace(el,0);
          } else {
            $.each(el_respon, function(index, el) {
              resp_0 += respSpace($(this),0);
            });
          }
          resp_0 = resp_0 !== '' ? '@media ' + query0 + '{' + resp_0 + '}' : '';
        },
        destroy : function() {}
    },
    handler1 = {
        match : function() {
          if (el !== undefined) {
            resp_1 += respSpace(el,1);
          } else {
            $.each(el_respon, function(index, el) {
              resp_1 += respSpace($(this),1);
            });
          }
          resp_1 = resp_1 !== '' ? '@media ' + query1 + '{' + resp_1 + '}' : '';
        },
        destroy : function() {}
    },
    handler2 = {
        match : function() {
          if (el !== undefined) {
            resp_2 += respSpace(el,2);
          } else {
            $.each(el_respon, function(index, el) {
              resp_2 += respSpace($(this),2);
            });
          }
          resp_2 = resp_2 !== '' ? '@media ' + query2 + '{' + resp_2 + '}' : '';
        },
        destroy : function() {}
    },
    handler3 = {
        match : function() {
          if (el !== undefined) {
            resp_3 += respSpace(el,3);
          } else {
            $.each(el_respon, function(index, el) {
              resp_3 += respSpace($(this),3);
            });
          }
          resp_3 = resp_3 !== '' ? '@media ' + query3 + '{' + resp_3 + '}' : '';
        },
        destroy : function() {}
    },
    handler4 = {
        match : function() {
          if (el !== undefined) {
            resp_4 += respSpace(el,4);
          } else {
            $.each(el_respon, function(index, el) {
              resp_4 += respSpace($(this),4);
            });
          }
          resp_4 = resp_4 !== '' ? '@media ' + query4 + '{' + resp_4 + '}' : '';
        },
        destroy : function() {}
    },
    handler5 = {
        match : function() {
          if (el !== undefined) {
            resp_5 += respSpace(el,5);
          } else {
            $.each(el_respon, function(index, el) {
              resp_5 += respSpace($(this),5);
            });
          }
          resp_5 = resp_5 !== '' ? '@media ' + query5 + '{' + resp_5 + '}' : '';
        },
        destroy : function() {}
    };
    enquire.register(query0, handler0, true);
    enquire.register(query1, handler1, true);
    enquire.register(query2, handler2, true);
    enquire.register(query3, handler3, true);
    enquire.register(query4, handler4, true);
    enquire.register(query5, handler5, true);
    if ($('style.respSpaceSc').length) {
      $('.respSpaceSc').html(resp_0+resp_1+resp_2+resp_3+resp_4+resp_5);
    }else{
      $('body').append('<style class="respSpaceSc">'+resp_0+resp_1+resp_2+resp_3+resp_4+resp_5+'</style>');
    }
  }
  
  /* ---------------------------------------------
   API
  --------------------------------------------- */
  KT.addItem = function(id, qty, backfunc) {
    var itemChange = id;
    var qty = qty || 1,
        ajax = {
          type: "POST",
          url: Shopify.root_url+"/cart/add.js",
          data: "quantity=" + qty + "&id=" + itemChange,
          dataType: "json",
          success: function(e) {
            window.location.href = Shopify.root_url+'/cart';
          },
          error: function(e) {
            alert('error');
          }
        };
    $.ajax(ajax)
  }
  KT.addItemFromFormAddMore = function(el_id) {
    var queue = [];
    $(el_id+' [name="quantity"]').each(function() {
      queue.push({
        "id": parseInt($(this).attr('data-id')),
        "quantity": parseInt($(this).val(), 10) || 0
      });
    });
    var ajax = {
          type: "POST",
          url: Shopify.root_url+"/cart/add.js",
          data: {'items': queue},
          dataType: "json",
          success: function(e) {
            window.location.href = Shopify.root_url+'/cart';
          },
          error: function(e) {
            alert('error');
          }
        };
    $.ajax(ajax)
  }
  KT.getProduct = function(handle, callback) {
    jQuery.getJSON(Shopify.root_url+'/products/' + handle + '.js', function (product, textStatus) {
      if ((typeof callback) === 'function') {
        callback(product);
      }
      else {
        console.log(product.title);
      }
    });
  };

  /* ---------------------------------------------
    Scripts ready
  --------------------------------------------- */
  $(document).ready(function() {
    KT.ajaxSearch();
    kt_quickView();
    kt_quickShop();
    kt_editOpts();
    embedRespon();
    css_banner_builded();
    KT.respSpaceSc();
    AutoloadWishlist();
    AddWishlist();
    RemoveWishlist();
    AutoloadCompare();
    AddCompare();
    RemoveCompare();
    KT.countdown();
    theme.suggest.enable ? suggestProducts() : null;

    // BLOG
    $(document).on('click', '.widget-cats .level-has-child>a i', function(e){
      e.preventDefault();
      $(this).parents('.level-has-child').first().find('.child_link').first().slideToggle();
    });

    // CART
    $(document)
    .on('click', '.mini-cart:not(.cart-none) .icon-link', function(e){
      e.preventDefault();
    })
    .on('click', 'input.kt_agree', function(){
      var layout = $(this).attr('data-layout');
      if ($(this).is(':checked')) {
        $('input.kt_agree[data-layout="'+layout+'"]').prop('checked',true);
        $('.alert-terms-conditions').alert('close');
        if (layout == 'checkout') {
          $('.additional-checkout-buttons').css('pointer-events', '');
        }
      }else{
        $('input.kt_agree[data-layout="'+layout+'"]').prop('checked',false);
        if (layout == 'checkout') {
          $('.additional-checkout-buttons').css('pointer-events', 'none');
        }
      }
    })
    .on('click', '.kt_agree_swich', function(e){
      var layout = $(this).attr('data-layout');
      if ($('input.kt_agree[data-layout="'+layout+'"]').length > 0 && $('input.kt_agree[data-layout="'+layout+'"]').is(':checked') == false) {
        e.preventDefault();
        e.stopPropagation();
        KT.loadScript('theme-alert', function(e,l){
          if (l == 'ok') {
            KT_Alert.terms_conditions(layout);
          }
        });
      }
    })
    if ($('input.kt_agree[data-layout="checkout"]').length > 0 && $('input.kt_agree[data-layout="checkout"]').is(':checked') == false) {
      $('.additional-checkout-buttons').css('pointer-events', 'none');
    }

    // CART MINI
    if($('.ajax__list-cart').length && theme.function.ajax_cart && theme.function.type_ajax_cart === 'drop'){
      $(document).on('mouseenter', '.mini-cart:not([onclick]) .icon-link', function(e) {
        if ($('.mini-cart').hasClass('load')) {
          $('.mini-cart').removeClass('load');
          $('.ajax__list-cart').addClass('loading')
          Shopify.KT_getCart();
        } else {
          return
        }
      });
    }
    $(document).on('click', '[onclick] a', function(e) {
      e.preventDefault();
    })

    // CART DRAWER
    $(document)
    .on('click', '.footer__cart-offcanvas .nav-link' ,function(){
      $('.cart-offcanvas__content').addClass('show-tab-floating');
      $('.'+$(this).attr('data-tab-content')).addClass('active');
    })
    .on('click', '.btn-x-tab-floating' ,function(){
      $('.cart-offcanvas__content').removeClass('show-tab-floating');
      $(this).parents('.tab-floating').removeClass('active');
    })
    $(document)
    .on('focusin', '#CartSpecialInstructions' ,function(){
      $('.note__cart-offcanvas').addClass('show');
      $('.note__cart-offcanvas .update').show();
    })
    .on('click', '.toggle_ship' ,function(){
      $('.cart-offcanvas .wrapper__shipping').toggleClass('show');
    })
    
    // BOTTOM BAR
    $(document).on('click', '.bottom__bar .mobile-menu-toggle', function (e) {
      e.preventDefault();
      $('.mobile-menu-wrapper.lazyload').attr('data-include',Shopify.root_url+'/cart?view=mobile-menu&q=category');
      if ($('.nav-link[data-type="item_categories_1"]').length > 0) {
        $('.nav-link[data-type="item_categories_1"]').trigger('click');
      }
    });

    // SCROLL TOP
    $(document).on('click', '.scroll_top', function() {
      $('html, body').animate( { scrollTop: 0 }, 600 );
    });
    
    $(document)
    .on('click', '.kt--drop-title', function(e) {
      e.preventDefault();
      var $this = $(this).parent();
      $this.toggleClass('show');
      $('.kt--drop-i.show').not($this).removeClass('show');
    })
    .on("click", function(e) {
      if ($(e.target).is('.kt--drop-i.show') === false && $(e.target).is('.kt--drop-i.show *') === false) {
        $('.kt--drop-i.show').removeClass("show");
      }
    })
    .on("click", ".kt--drop-in a, .kt--drop-in [data-href]", function(e) {
      var $this = $(this).parents('.kt--drop-i');
      $this.css("pointer-events","none");
      setTimeout(function(){
        $this.css("pointer-events","")
      }, 400);
    });

    $(document).on('show.bs.tab', '.tab-list-ajax button[data-bs-toggle="tab"]', function (event) {
      var tab_content = $(this).closest('.tab-list-ajax').find('.tab-content');
      if ($($(this).attr('data-bs-target')).find('.swiper-wrapper.lazyload').length > 0) {
        var height = tab_content.innerHeight();
        tab_content.addClass('including').css('height', height);
        $($(this).attr('data-bs-target')).find('.button-loadmore').css('opacity', '0');
      }
    })

    $(document).on('click', '.btn-onclick', function(e) {
      $(this).addClass('loading').removeClass('loaded');
    })

    if ( $(window).width() >= 992 && $('.sticky-content').length > 0) {
      $('.sticky-content').stick_in_parent({
        offset_top: 80
      });
    }
    $(document)
    .on('click', '.drop-mobile .label-drop', function(e){
      e.preventDefault();
      $(this).parent().toggleClass('show');
    })
    .on('click', function(e){
      if ($(e.target).is('.drop-mobile.show *') === false ) {
        $('.drop-mobile.show').removeClass("show");
      }
    });

    // Scroll To button
    var $scrollTo = $('.kt_home_slide .btn');
    if ( $scrollTo.length ) {
      $scrollTo.on('click', function(e) {
        var target = $(this).attr('href');
        if (target.length > 1 && target.charAt(0) === '#') {
          e.preventDefault();
          var $target = $(target);
          var scrolloffset = ($(window).width() >= 992) ? ($target.offset().top - 52) : $target.offset().top
          $('html, body').animate({
            'scrollTop': scrolloffset
          }, 600);
        }
      });
    }

    if ($('#currency_form').length > 0) {
      $(document).on('click', '.curcy_item', function(event){
        event.preventDefault();
        $('.curcy_list').css('pointer-events', 'none');
        var newCurrency =  $(this).data('currency');
        $('#currency_form input[name="currency"]').val(newCurrency);
        $('#currency_form').submit();
      })
    }
    /* ---------------------------------------------
     Form trick
    --------------------------------------------- */
    $(document)
    .on('click', '.product-thumb a[data-href]', function(event) {
      event.preventDefault();
      window.location.href = $(this).attr('data-href');
    })
    if (!themeAjaxCart) {
      $(document)
      .on('click', '[data-submit]:not(.kt__quick-shop)', function(event) {
        event.preventDefault();
        $(this).parents('form').submit();
      })
    }

    // REVIEW TAB
    if ($('#product-tabs').length > 0) {
      $(document).on('click', '.rating-reviews.sg', function(event) {
        event.preventDefault();
        $('#product-tabs .tb_review').trigger('click');
        document.querySelector($('#product-tabs .tb_review').attr('data-bs-target')).scrollIntoView({
          behavior: 'smooth'
        });
      })
    }

    // REVIEW ACCORDION
    if ($('#product-accordion').length > 0) {
      $(document).on('click', '.rating-reviews.sg', function(event) {
        event.preventDefault();
        $('#product-accordion .tb_review').trigger('click');
        document.querySelector($('#product-accordion .tb_review').attr('data-bs-target')).scrollIntoView({
          behavior: 'smooth'
        });
      })
    }
    
    $(document).on('click', '.box-search .icon-link' ,function(e){
      var $this = $(this)
      setTimeout(function() {
        $this.parents('.box-search').find('.inner.inline .search').focus();
      }, 310);
    })
  });

  /* ---------------------------------------------
   Scripts scroll
   --------------------------------------------- */
  $(window).scroll($.throttle( 150, function() {
    // Show hide scrolltop button
    if($(this).scrollTop() > theme.window_H ) {
      $('.scroll_top').addClass('show');
    } else {
      $('.scroll_top').removeClass('show');
    }
  }));
  
  /* ---------------------------------------------
   Scripts resize
   --------------------------------------------- */
  $(window).on("resize", function() {
    KT.respSpaceSc();
    if (theme.function.type_ajax_cart == "offcanvas") {KT.drawResize();}
  });


  if(Shopify.designMode){
    var designMode_refresh = function () {
      css_banner_builded();
      KT.countdown();
      KT.respSpaceSc();
      embedRespon();
    }
    $(document)
    .on('shopify:section:load', designMode_refresh)
    .on('shopify:block:select', designMode_refresh);
  }

})( jQuery );