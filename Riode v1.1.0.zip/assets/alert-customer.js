var list = {
	"gun-safe-supply-co.myshopify.com": {
		"rate": 1,
		"user": "Barry748",
		"license": "d1d0f363-b720-43ac-81e8-2d21e7180136"
	},
	"everythingvapes.myshopify.com": {
		"rate": 3,
		"user": "Roger_Helen",
		"license": "8cdd46ea-d86b-427a-b113-4d380c2e302e"
	},
	"riode-demo-1.myshopify.com": {
		"rate": 3,
		"user": "Roger_Helen",
		"license": "8cdd46ea-d86b-427a-b113-4d380c2e302e"
	}
}
if (list[shopURL]) {
	console.log(list[shopURL]);
}